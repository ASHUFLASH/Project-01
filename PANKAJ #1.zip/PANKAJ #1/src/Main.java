import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a non-negative integer to calculate its factorial: ");
        int number = scanner.nextInt();
        
        try {
            long factorial = FactorialCalculator.calculateFactorial(number);
            System.out.println("Factorial of " + number + " is: " + factorial);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
        
        scanner.close();
    }
}
